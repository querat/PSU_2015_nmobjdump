#!/bin/bash
## run.sh for  in /home/querat_g/tmp/PSU_2015_nmobjdump
##
## Made by querat_g
## Login   <querat_g@epitech.net>
##
## Started on  Tue Feb 16 11:20:33 2016 querat_g
## Last update Thu Feb 25 18:12:36 2016 querat_g
##

## ------------------------------------------------------------------------- //
## Moulinette destinée à tester le my_objdump
##    Pas d'arguments => tests automatiques
##    Arguments => diff avec objdump -fs
## --------------------------------------------------------------------- //

## !!! NE GÈRE PAS LES .a (c'est pas compliqué à rajouter) ----------- _/

#couleurs
function echolor { echo -e "$@"; }
RED="\e[1;31m";
GREEN="\e[1;32m";
YELLOW="\e[1;33m";
BROWN="\e[0;33m";
BLUE="\e[1;34m";
PINK="\e[1;35m";
CYAN="\e[1;36m";
WHITE="\e[0m";

# variables
theirFile="tmp/diffUnix.tmp";
myFile="tmp/diffMine.tmp";
diffFile="tmp/res.tmp";

err=1;
# Compilation (ou pas)
clear;
echolor $CYAN"*** Compilation ********************************"$WHITE;
make && err=0 &&
(echolor $GREEN"Compilation OK ! ******************************"$WHITE) ||
(echolor $RED"Ne compile pas ! ******************************"$WHITE)
# Erreur -> GTFO
if [[ err -eq 1 ]]
then
    exit 42;
fi
# !Compilation

# création du directory tmp si il n'existe pas
if [ ! -d "tmp" ]; then
    rm tmp -f;
    mkdir tmp;
fi
# !directory tmp

# fonction utilisée pour tous les tests ------------------------------------ ||
function runTest {

    echolor $CYAN"$@"$WHITE;
    
    # execution  des commandes
    # mon objdump
    retMy=$(./my_nm "$@" 2>&1  | cat -e > $myFile)
    # objdump système
    retTheir=$(nm "$@"   2>&1  | cat -e > $theirFile)
    # diff dans un fichier tmp
    diff -y   $theirFile $myFile 2>&1 > $diffFile -W175 #--suppress-common-lines;

    myDiff=$(cat $diffFile);

    if [ -z "$myDiff" ]; then
	echolor $GREEN"test successful !" $WHITE;
	# echo 	"Expected output : "; cat $myFile;
    else
	echolor $RED"!!Diff found!!";
	echolor "Dumped into $diffFile"
	echolor $YELLOW"THEIR\t\t\t\t\t\t\t\tYOURS"$WHITE;
	cat $diffFile ;
	echolor $WHITE;
	read -p "Press enter to continue
";
    fi
    echo;
} # !runtest() ------------------------------------------------------------- ||

# lancement des tests ------------------------------------------------------ ||
clear;
echolor $RED"Moulinex !"$WHITE;

# Pas d'arguments au script = moulinette par défaut
if [ -z "$@" ]; then

    # on diff les .o dans le repo et on les diff
    for o_file in `find . -name "*.o"`; do
	./moul_my_nm.sh $o_file;
	#sleep 1;
    done

    # on diff les .o dans /usr et on les diff
    for oo_file in `find /usr/ -name "*.o"`; do
	./moul_my_nm.sh $oo_file;
	#sleep 1;
    done

    #on diff les .so dans /usr/
    for file in `find /usr/ -name "*.so"`; do
	if [ "$file" != "/usr/lib/firefox/libxul.so" ]; then
	    ./moul_my_nm.sh $file;
	fi
	#sleep 1;
    done
    
# Arguments = moulinette avec les arguments passés au run.sh    
else
    echolor $CYAN "Running with run.sh arguments" $WHITE;
    runTest "$@"
fi
# !tests ------------------------------------------------------------------- ||
