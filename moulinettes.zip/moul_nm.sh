#!/bin/bash
## moul.sh for  in /home/querat_g/tmp/PSU_2015_nmobjdump
## 
## Made by querat_g
## Login   <querat_g@epitech.net>
## 
## Started on  Fri Feb 26 10:34:34 2016 querat_g
## Last update Fri Feb 26 15:59:54 2016 querat_g
##

#couleurs
function echolor { echo -e "$@"; }
function color() { echo -ne "$@";}
LRED="\e[1;31m";
RED="\e[0;31m";
LGREEN="\e[1;32m";
GREEN="\e[0;32m";
YELLOW="\e[1;33m";
BROWN="\e[0;33m";
BLUE="\e[1;34m";
PINK="\e[1;35m";
CYAN="\e[1;36m";
WHITE="\e[0m";

# variables
theirFile="tmp/diffUnix.tmp";
myFile="tmp/diffMine.tmp";
diffFile="tmp/res.tmp";

err=1;
# Compilation (ou pas)
clear;
echolor $CYAN"*** Compilation ********************************"$WHITE;
make && err=0 &&
(echolor $LGREEN"Compilation OK ! ******************************"$WHITE) ||
(echolor $LRED"Ne compile pas ! ******************************"$WHITE)
# Erreur -> GTFO
if [[ err -eq 1 ]]
then
    exit 42;
fi
# !Compilation

# création du directory tmp si il n'existe pas
if [ ! -d "tmp" ]; then
    rm tmp -f;
    mkdir tmp;
fi
# !directory tmp

# Lexer set sur les \n
IFS=$'\n'

function runTest() {
    nm "$@" | cat > "$theirFile";
    ./my_nm "$@" | cat > "$myFile";
    
    retTheir=`cat $theirFile`
    retMy=`cat $myFile`
    
    for theirLine in $retTheir
    do
	
	# Réinit d'une var utilisée plus bas
	OUTPUT_DIFFERS=0
	
	# parsing du retour de nm
	theirName=$(echo $theirLine | sed -E 's/\s+/ /g' | cut -d\  -f3);
	theirFlag=$(echo $theirLine | sed -E 's/\s+/ /g' | cut -d\  -f2);
        theirAddr=$(echo $theirLine | sed -E 's/\s+/ /g' | cut -d\  -f1);
        
	# recherche du symbole dans l'output nm
	myLine=`egrep "\s$theirName$" $myFile | sed -E 's/\s+/ /g'`;	
	myName=$(echo $myLine | cut -d\  -f3)

	# symbole non trouvé dans mon output ?
	if [ -z "$myName" ] || [ -z "$myLine" ] 
	then
	    clear;
	    echolor $CYAN"in file $@"$WHITE
	    echolor $LRED"Flag $theirName not found in your output"$WHITE
	    read -p "Press enter to continue"
	else # symbole présent >> on continue le test
	    
	    # Parsing du retour de my_nm (addresse et flag)
	    myFlag=$(echo $myLine | cut -d\  -f2);
            myAddr=$(echo $myLine | cut -d\  -f1);
            
	    # drame
	    if [[ "$myFlag" != "$theirFlag" ]]; then OUTPUT_DIFFERS=1; fi
	    if [[ "$myAddr" != "$theirAddr" ]]; then OUTPUT_DIFFERS=1; fi
	    
	    if [ $OUTPUT_DIFFERS -eq 0 ];
	    then # OK
		printf "$LGREEN%s$YELLOW%s$WHITE\n" "<OK> " "$theirName"
	    else # KAPUT
		clear;
		printf $CYAN"in file \"$@\""$WHITE
		printf "\n$LRED%s$YELLOW%s$WHITE\n" "<KO> " "$theirName"
		
		if [[ "$myFlag" != "$theirFlag" ]]
		then
		    echo -ne $RED"Flag differs : theirs > $theirFlag yours > $myFlag\n"$WHITE
		elif [[ "$myAddr" != "$theirAddr" ]]
		then
	    	    echo -ne $RED"Address differs : theirs > $theirAddr yours > $myAddr\n"$WHITE
		fi
		echo ""
		read -p "press enter to continue"
	    fi
	fi
    done
}

if [ ! -z "$1" ]
then	# Arguments au script >> on run un test unitaire avec cet arg
    runTest $1
else    # Pas d'arguments == batterie de tests par défaut

    clear;
    
    # exe !
    runTest my_nm
    runTest my_objdump
    
    # $PWD
    for testFile in `find . -name "*.o" -or -name "*.so"`
    do
    	clear;
    	echolor $CYAN "file >> " $testFile $WHITE
    	sleep 0.6;
    	runTest $testFile
    done

    # /usr
    for testFile in `find /usr/ -name "*.o" -or -name "*.so"`
    do
	clear;
	echolor $CYAN "file >> " $testFile $WHITE
	sleep 0.6;
	runTest $testFile
    done
fi
